<?php
namespace Aws\Kinesis;

use Aws\AwsClient;

/**
 * This client is used to interact with the **Amazon Kinesis** service.
 */
class KinesisClient extends AwsClient {}
