<?php
namespace Aws\AutoScaling;

use Aws\AwsClient;

/**
 * Auto Scaling client.
 */
class AutoScalingClient extends AwsClient {}
