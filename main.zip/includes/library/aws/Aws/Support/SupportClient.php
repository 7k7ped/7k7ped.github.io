<?php
namespace Aws\Support;

use Aws\AwsClient;

/**
 * AWS Support client.
 */
class SupportClient extends AwsClient {}
