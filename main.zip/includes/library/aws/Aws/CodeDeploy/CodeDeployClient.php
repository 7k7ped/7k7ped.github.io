<?php
namespace Aws\CodeDeploy;

use Aws\AwsClient;

/**
 * This client is used to interact with AWS CodeDeploy
 */
class CodeDeployClient extends AwsClient {}
