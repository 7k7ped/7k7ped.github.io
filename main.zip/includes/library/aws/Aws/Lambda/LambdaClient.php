<?php
namespace Aws\Lambda;

use Aws\AwsClient;

/**
 * This client is used to interact with AWS Lambda
 */
class LambdaClient extends AwsClient {}
