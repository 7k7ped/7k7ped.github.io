<?php
namespace Aws\CloudHsm;

use Aws\AwsClient;

/**
 * This client is used to interact with **AWS CloudHSM**.
 */
class CloudHsmClient extends AwsClient {}
