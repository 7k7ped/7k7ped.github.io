<?php
namespace Aws\StorageGateway;

use Aws\AwsClient;

/**
 * AWS Storage Gateway client.
 */
class StorageGatewayClient extends AwsClient {}
